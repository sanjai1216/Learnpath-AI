# LearnPath AI - Setup & Integration Guide

## 📋 Overview

This is a **full-stack AI-powered recommendation system** that matches users with personalized MOOCs and internship opportunities.

### Architecture

```
┌─────────────────┐         ┌──────────────────┐         ┌─────────────┐
│                 │         │                  │         │             │
│  Frontend       │ ◄──────►│  Backend (FastAPI)│◄────────►│ SQLite DB   │
│  (index.html)   │  REST   │  (backend.py)    │  Queries │ (moocs.db)  │
│                 │  JSON   │                  │  SQL     │             │
└─────────────────┘         └──────────────────┘         └─────────────┘
      Browser                    Python Server          Database
      React Logic                Auth + API              Courses +
      UI Components              Recommendations         Internships +
      Token Storage              Resume Upload           Users
```

## 🚀 Quick Start (5 minutes)

### 1️⃣ Install Python Dependencies

```bash
pip install -r requirements.txt
```

### 2️⃣ Run the Backend Server

```bash
python backend.py
```

You should see:
```
[✓] Database initialized successfully
[✓] Starting LearnPath AI on http://0.0.0.0:8080
[✓] Open browser at http://localhost:8080
```

### 3️⃣ Open in Browser

```
http://localhost:8080
```

**Done!** The frontend is automatically served from the same server.

---

## 📁 Project Structure

```
learnpath-ai/
├── backend.py           # FastAPI server & API endpoints
├── database.py          # SQLite database & recommendation engine
├── index.html           # Frontend (HTML + CSS + JavaScript)
├── requirements.txt     # Python dependencies
├── moocs.db            # SQLite database (auto-created)
└── README.md           # This file
```

---

## 🔌 How Everything Connects

### 1. **Frontend (index.html)**
- **What it does:** User interface for registration, login, search, and results
- **How it connects:** Makes REST API calls to the backend using `fetch()`
- **Key feature:** Auto-detects API URL from browser location (`window.location.origin`)

```javascript
// Frontend automatically connects to same server
const API = window.location.origin;  // http://localhost:8080

// Example API call
fetch(`${API}/api/recommend`, {
  method: "POST",
  headers: { "Authorization": "Bearer " + token },
  body: JSON.stringify({ skills, role })
})
```

### 2. **Backend (backend.py)**
- **What it does:** Serves frontend, handles authentication, processes recommendations
- **How it connects:** 
  - Serves `index.html` at root route `/`
  - Provides REST API endpoints for frontend to call
  - Queries database for courses and internships

```python
@app.get("/", response_class=HTMLResponse)
def serve_frontend():
    """Frontend is served from same server"""
    with open("index.html", "r", encoding="utf-8") as f:
        return HTMLResponse(content=f.read())

@app.post("/api/recommend")
def recommend(req: RecommendRequest, current_user: dict = Depends(get_current_user)):
    """API endpoint called by frontend"""
    courses = [dict(r) for r in conn.execute("SELECT * FROM courses")]
    internships = [dict(r) for r in conn.execute("SELECT * FROM internships")]
    # Rank items using AI algorithm
    return { "courses": ranked_courses, "internships": ranked_internships }
```

### 3. **Database (database.py & moocs.db)**
- **What it does:** Stores users, courses, internships; provides recommendation algorithm
- **How it connects:** Backend queries it using SQLite3

```python
def rank_items(user_skills, user_role, items):
    """AI matching using TF-IDF + cosine similarity"""
    # Extracts skills from user input
    # Matches against course/internship tags & descriptions
    # Returns items ranked by match percentage (0-100%)
```

---

## 🔐 Authentication Flow

### Registration
```
1. User fills form → Frontend
2. Frontend sends POST /api/register → Backend
3. Backend hashes password, saves to database
4. Backend returns JWT token
5. Frontend stores token in localStorage
6. User is logged in!
```

### Login
```
1. User enters email/password → Frontend
2. Frontend sends POST /api/login → Backend
3. Backend verifies credentials from database
4. Backend returns JWT token
5. Frontend stores token, makes authenticated requests
```

### Protected Endpoints
```
1. Frontend includes token: "Authorization: Bearer <token>"
2. Backend validates token with get_current_user()
3. If valid → Process request
   If invalid → Return 401 Unauthorized
```

---

## 🎯 API Endpoints Reference

### Authentication
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/register` | Create new account |
| POST | `/api/login` | Login with email/password |
| GET | `/api/me` | Get current user (protected) |

### Recommendations
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/recommend` | Get courses & internships (protected) |
| POST | `/api/upload-resume` | Upload & parse resume (protected) |

### System
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/` | Serve frontend HTML |
| GET | `/health` | Health check |

---

## 📊 Recommendation Algorithm

The backend uses **hybrid matching** combining 3 techniques:

### 1. **TF-IDF + Cosine Similarity** (50%)
Compares user skills/role against course tags and descriptions using vector similarity
```python
# Measures relevance: how well does the course match keywords?
# Example: "Python Machine Learning" matches "ML Engineer" → high score
```

### 2. **Heuristic Token Matching** (30%)
Counts how many user tokens appear in item text
```python
# Fast matching: Python AND Machine Learning AND Data = 3/3 matches
```

### 3. **Level Matching** (20%)
Matches course difficulty level to user experience
```python
# Beginner course → Junior role → Higher score
# Advanced course → Senior role → Higher score
```

**Result:** Courses/internships ranked 0-100% match

---

## 🗄️ Database Schema

### Users Table
```sql
CREATE TABLE users (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)
```

### Courses Table
```sql
CREATE TABLE courses (
    id INTEGER PRIMARY KEY,
    title TEXT NOT NULL,
    provider TEXT,
    level TEXT,           -- Beginner, Intermediate, Advanced
    duration TEXT,
    tags TEXT,           -- "Python ML data science"
    description TEXT,
    url TEXT
)
```

### Internships Table
```sql
CREATE TABLE internships (
    id INTEGER PRIMARY KEY,
    title TEXT NOT NULL,
    company TEXT,
    location TEXT,
    stipend TEXT,
    tags TEXT,          -- "Python backend API"
    description TEXT,
    url TEXT
)
```

---

## 🐛 Troubleshooting

### **Issue: "Cannot connect to server"**
```
✓ Make sure backend is running: python backend.py
✓ Check port 8080 is not in use: lsof -i :8080
✓ Try: http://localhost:8080 (not 127.0.0.1)
```

### **Issue: "Database not found"**
```
✓ Run backend once to auto-create moocs.db
✓ Check permissions in directory
✓ Delete moocs.db and restart to reset
```

### **Issue: "401 Unauthorized"**
```
✓ Token expired? Try logging in again
✓ Browser localStorage cleared? Log back in
✓ Check browser DevTools → Application → Local Storage
```

### **Issue: Login/Register not working**
```
✓ Check email format (must have @)
✓ Password must be ≥6 characters
✓ Email must be unique (not already registered)
✓ Check backend console for error messages
```

---

## 📝 Environment Variables

### Optional Configuration

Create a `.env` file to customize:

```bash
# Secret key for JWT tokens (default: "smartmoocs-secret-key-2026")
SECRET_KEY=your-super-secret-key

# Server port (default: 8080)
PORT=8080

# Database file location (default: moocs.db in current directory)
# DATABASE_FILE=./moocs.db
```

### Usage

```python
# In backend.py
SECRET_KEY = os.environ.get("SECRET_KEY", "smartmoocs-secret-key-2026")
port = int(os.environ.get("PORT", 8080))
```

---

## 🔄 Data Flow Examples

### Example 1: User Registration
```
1. User clicks "Create Account"
2. Enters: name="John", email="john@example.com", password="pass123"
3. Frontend validates: password ≥ 6 chars, email has @
4. Frontend calls: POST /api/register
   {
     "name": "John",
     "email": "john@example.com",
     "password": "pass123"
   }
5. Backend:
   - Validates input
   - Checks email not duplicate
   - Hashes password: bcrypt("pass123") → "$2b$12$..."
   - Saves to database
   - Creates JWT token with user data
   - Returns: {"token": "eyJ0eXAi...", "name": "John"}
6. Frontend stores token in localStorage
7. Frontend redirects to home page
```

### Example 2: Getting Recommendations
```
1. User enters:
   Skills: "Python, Machine Learning"
   Role: "Data Scientist"
2. Frontend calls: POST /api/recommend
   {
     "skills": "Python, Machine Learning",
     "role": "Data Scientist"
   }
   With header: "Authorization: Bearer <token>"
3. Backend:
   - Validates JWT token
   - Fetches all courses from database
   - For each course:
     - Calculates similarity score (0-100)
     - Compares title/tags/description to user input
   - Sorts by match percentage
   - Returns top 10 courses + top 10 internships
4. Frontend displays results with match percentages
5. User clicks "Enroll Now" → External link opens
```

---

## 🚀 Deployment

### Local Network
```bash
# Allow other devices to access
uvicorn backend:app --host 0.0.0.0 --port 8080
# Access from other device: http://<your-ip>:8080
```

### Production (Example: Heroku)
```bash
# Create Procfile
echo "web: uvicorn backend:app --host 0.0.0.0 --port \$PORT" > Procfile

# Deploy
heroku create learnpath-ai
git push heroku main
```

### Docker
```bash
# Create Dockerfile
FROM python:3.10
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
CMD ["python", "backend.py"]

# Build and run
docker build -t learnpath-ai .
docker run -p 8080:8080 learnpath-ai
```

---

## 📚 Technologies Used

| Component | Technology | Purpose |
|-----------|-----------|---------|
| **Frontend** | HTML5, CSS3, Vanilla JS | User interface |
| **Backend** | FastAPI, Python 3.8+ | REST API, Auth |
| **Database** | SQLite3 | Data storage |
| **Security** | JWT, bcrypt | Token & password |
| **ML** | scikit-learn | TF-IDF matching |

---

## 🎓 Learning Resources

- **FastAPI:** https://fastapi.tiangolo.com
- **JWT Auth:** https://tools.ietf.org/html/rfc7519
- **SQLite:** https://www.sqlite.org/docs.html
- **scikit-learn:** https://scikit-learn.org/stable/
- **REST APIs:** https://restfulapi.net

---

## 📞 Support

If something doesn't work:
1. Check the **Troubleshooting** section above
2. Look at backend console output: `python backend.py`
3. Check browser console: F12 → Console tab
4. Verify all dependencies: `pip install -r requirements.txt`

---

**Made with ❤️ by LearnPath AI Team**

#!/bin/bash

# LearnPath AI - Quick Start Script
# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${BLUE}╔════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║   LearnPath AI - Quick Start Script     ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════╝${NC}\n"

# Check Python version
echo -e "${YELLOW}[1/4]${NC} Checking Python..."
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}✗ Python 3 is not installed${NC}"
    exit 1
fi
python_version=$(python3 --version 2>&1 | awk '{print $2}')
echo -e "${GREEN}✓ Python $python_version found${NC}\n"

# Install dependencies
echo -e "${YELLOW}[2/4]${NC} Installing dependencies..."
if python3 -m pip install -r requirements.txt > /dev/null 2>&1; then
    echo -e "${GREEN}✓ Dependencies installed${NC}\n"
else
    echo -e "${RED}✗ Failed to install dependencies${NC}"
    exit 1
fi

# Check if database exists
echo -e "${YELLOW}[3/4]${NC} Preparing database..."
if [ -f "moocs.db" ]; then
    echo -e "${GREEN}✓ Database found${NC}"
else
    echo -e "${YELLOW}→ Database will be created on first run${NC}"
fi
echo ""

# Start server
echo -e "${YELLOW}[4/4]${NC} Starting LearnPath AI...\n"
echo -e "${GREEN}╔════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║   Server is running!                   ║${NC}"
echo -e "${GREEN}╠════════════════════════════════════════╣${NC}"
echo -e "${GREEN}║   🌐 Open: http://localhost:8080       ║${NC}"
echo -e "${GREEN}║   🛑 Stop:  Press Ctrl+C               ║${NC}"
echo -e "${GREEN}╚════════════════════════════════════════╝${NC}\n"

python3 backend.py

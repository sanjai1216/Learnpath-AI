from fastapi import FastAPI, HTTPException, Depends, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from datetime import datetime, timedelta
from passlib.context import CryptContext
from jose import JWTError, jwt
import os, uvicorn, json

from database import (
    init_db, get_db_connection, rank_items,
    get_user_by_email, create_user
)

SECRET_KEY  = os.environ.get("SECRET_KEY", "smartmoocs-secret-key-2026")
ALGORITHM   = "HS256"
TOKEN_HOURS = 24

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
security    = HTTPBearer(auto_error=False)

app = FastAPI(title="LearnPath AI")

# ── CORS Configuration ────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, set to specific origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Helpers ───────────────────────────────────
def hash_password(pw):       
    return pwd_context.hash(pw)

def verify_password(p, h):   
    return pwd_context.verify(p, h)

def create_token(data):
    payload = data.copy()
    payload["exp"] = datetime.utcnow() + timedelta(hours=TOKEN_HOURS)
    return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)

def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    if not credentials:
        raise HTTPException(status_code=401, detail="Not authenticated")
    try:
        return jwt.decode(credentials.credentials, SECRET_KEY, algorithms=[ALGORITHM])
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid or expired token")

# ── Schemas ───────────────────────────────────
class RegisterRequest(BaseModel):
    name: str
    email: str
    password: str

class LoginRequest(BaseModel):
    email: str
    password: str

class RecommendRequest(BaseModel):
    skills: str
    role: str

# ── Startup ───────────────────────────────────
@app.on_event("startup")
def startup():
    init_db()
    print("[✓] Database initialized successfully")

# ── Serve Frontend ────────────────────────────
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

@app.get("/", response_class=HTMLResponse)
def serve_frontend():
    """Serves the main HTML file"""
    html_path = os.path.join(BASE_DIR, "index.html")
    try:
        with open(html_path, "r", encoding="utf-8") as f:
            return HTMLResponse(content=f.read())
    except FileNotFoundError:
        return HTMLResponse(content="<h1>404: index.html not found</h1>", status_code=404)

@app.get("/health")
def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "app": "LearnPath AI"}

# ── Auth Endpoints ────────────────────────────
@app.post("/api/register")
def register(req: RegisterRequest):
    """Register a new user"""
    # Validation
    if not req.name or not req.email or not req.password:
        raise HTTPException(status_code=400, detail="All fields required")
    if len(req.password) < 6:
        raise HTTPException(status_code=400, detail="Password must be at least 6 characters")
    if not "@" in req.email:
        raise HTTPException(status_code=400, detail="Invalid email format")
    
    # Check if user exists
    if get_user_by_email(req.email):
        raise HTTPException(status_code=409, detail="Email already registered")
    
    # Create user
    user = create_user(req.name, req.email, hash_password(req.password))
    if not user:
        raise HTTPException(status_code=500, detail="Registration failed")
    
    # Create JWT token
    token = create_token({
        "sub": str(user["id"]), 
        "email": user["email"], 
        "name": user["name"]
    })
    
    return {
        "status": "success", 
        "token": token, 
        "name": user["name"], 
        "email": user["email"],
        "message": "Registration successful"
    }

@app.post("/api/login")
def login(req: LoginRequest):
    """Login user and return JWT token"""
    if not req.email or not req.password:
        raise HTTPException(status_code=400, detail="Email and password required")
    
    user = get_user_by_email(req.email)
    if not user or not verify_password(req.password, user["password_hash"]):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    
    token = create_token({
        "sub": str(user["id"]), 
        "email": user["email"], 
        "name": user["name"]
    })
    
    return {
        "status": "success", 
        "token": token, 
        "name": user["name"], 
        "email": user["email"],
        "message": "Login successful"
    }

@app.get("/api/me")
def get_me(current_user: dict = Depends(get_current_user)):
    """Get current user info"""
    return {
        "name": current_user["name"], 
        "email": current_user["email"],
        "user_id": current_user["sub"]
    }

# ── Recommendation Endpoints ──────────────────
@app.post("/api/recommend")
def recommend(req: RecommendRequest, current_user: dict = Depends(get_current_user)):
    """Get personalized course and internship recommendations"""
    if not req.skills or not req.role:
        raise HTTPException(status_code=400, detail="Skills and role are required")
    
    try:
        conn = get_db_connection()
        courses     = [dict(r) for r in conn.execute("SELECT * FROM courses").fetchall()]
        internships = [dict(r) for r in conn.execute("SELECT * FROM internships").fetchall()]
        conn.close()
        
        return {
            "status": "success",
            "courses": rank_items(req.skills, req.role, courses, "course")[:10],
            "internships": rank_items(req.skills, req.role, internships, "internship")[:10],
        }
    except Exception as e:
        print(f"[Error] Recommendation failed: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to get recommendations")

# ── Resume Upload ─────────────────────────────
@app.post("/api/upload-resume")
async def upload_resume(resume: UploadFile = File(...), current_user: dict = Depends(get_current_user)):
    """Upload and parse resume to extract skills"""
    if not resume or not resume.filename:
        raise HTTPException(status_code=400, detail="No resume file provided")
    
    allowed_types = ["application/pdf", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "text/plain"]
    if resume.content_type not in allowed_types:
        raise HTTPException(status_code=400, detail="Only PDF, DOCX, or TXT files allowed")
    
    try:
        content = await resume.read()
        
        # Simple skill extraction (placeholder - can be improved)
        # In production, use pdfminer, python-docx, or other parsers
        if resume.content_type == "text/plain":
            text = content.decode("utf-8", errors="ignore")
        else:
            # For now, return mock data
            text = ""
        
        # Mock extraction - in production, parse actual content
        extracted_skills = extract_skills_from_text(text)
        inferred_role = infer_role_from_text(text)
        
        return {
            "status": "success",
            "message": f"Resume '{resume.filename}' uploaded successfully",
            "extracted_skills": extracted_skills,
            "inferred_role": inferred_role
        }
    except Exception as e:
        print(f"[Error] Resume upload failed: {str(e)}")
        raise HTTPException(status_code=500, detail="Resume processing failed")

def extract_skills_from_text(text: str) -> str:
    """Extract skills from resume text"""
    common_skills = [
        "Python", "JavaScript", "Java", "C++", "C#", "Go", "Rust",
        "React", "Vue", "Angular", "Node.js", "Django", "Flask",
        "SQL", "MongoDB", "PostgreSQL", "AWS", "GCP", "Azure",
        "Docker", "Kubernetes", "Git", "Machine Learning", "Data Analysis",
        "HTML", "CSS", "TypeScript", "GraphQL", "REST API"
    ]
    
    found_skills = []
    text_lower = text.lower()
    for skill in common_skills:
        if skill.lower() in text_lower:
            found_skills.append(skill)
    
    return ", ".join(found_skills) if found_skills else "Python, Machine Learning, Data Analytics"

def infer_role_from_text(text: str) -> str:
    """Infer role from resume text"""
    role_keywords = {
        "Data Scientist": ["data scientist", "machine learning", "data analysis", "analytics"],
        "Backend Developer": ["backend", "api", "server", "database", "microservice"],
        "Frontend Developer": ["frontend", "react", "vue", "angular", "ui/ux", "css"],
        "Full Stack Developer": ["full stack", "fullstack", "end-to-end"],
        "DevOps Engineer": ["devops", "kubernetes", "docker", "ci/cd", "cloud"],
        "Product Manager": ["product manager", "product management", "agile"],
    }
    
    text_lower = text.lower()
    for role, keywords in role_keywords.items():
        if any(kw in text_lower for kw in keywords):
            return role
    
    return "Software Engineer"

# ── Run ───────────────────────────────────────
if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8080))
    print(f"\n[✓] Starting LearnPath AI on http://0.0.0.0:{port}")
    print(f"[✓] Open browser at http://localhost:{port}\n")
    uvicorn.run("backend:app", host="0.0.0.0", port=port, reload=True)

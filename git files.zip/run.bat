@echo off
REM LearnPath AI - Quick Start Script (Windows)

setlocal enabledelayedexpansion

echo.
echo ╔════════════════════════════════════════╗
echo ║   LearnPath AI - Quick Start Script     ║
echo ╚════════════════════════════════════════╝
echo.

REM Check Python version
echo [1/4] Checking Python...
python --version >nul 2>&1
if errorlevel 1 (
    echo ✗ Python is not installed or not in PATH
    echo.
    echo Please download Python from: https://www.python.org/downloads/
    echo Make sure to check "Add Python to PATH" during installation
    pause
    exit /b 1
)
for /f "tokens=2" %%i in ('python --version 2^>^&1') do set python_version=%%i
echo ✓ Python %python_version% found
echo.

REM Install dependencies
echo [2/4] Installing dependencies...
python -m pip install -r requirements.txt >nul 2>&1
if errorlevel 1 (
    echo ✗ Failed to install dependencies
    pause
    exit /b 1
)
echo ✓ Dependencies installed
echo.

REM Check database
echo [3/4] Preparing database...
if exist "moocs.db" (
    echo ✓ Database found
) else (
    echo → Database will be created on first run
)
echo.

REM Start server
echo [4/4] Starting LearnPath AI...
echo.
echo ╔════════════════════════════════════════╗
echo ║   Server is running!                   ║
echo ╠════════════════════════════════════════╣
echo ║   🌐 Open: http://localhost:8080       ║
echo ║   🛑 Stop:  Press Ctrl+C               ║
echo ╚════════════════════════════════════════╝
echo.

python backend.py
pause

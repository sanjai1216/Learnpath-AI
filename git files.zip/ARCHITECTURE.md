# LearnPath AI - Architecture & Connection Details

## 🏗️ System Architecture

```
┌─────────────────────────────────────────────────────────────────────────┐
│                        USER'S BROWSER (Client)                          │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                           │
│  ┌────────────────────────────────────────────────────────────────────┐ │
│  │                      Frontend (index.html)                         │ │
│  │                                                                    │ │
│  │  HTML Structure:          CSS Styling:          JS Logic:         │ │
│  │  ┌──────────────────┐     ┌──────────────────┐ ┌──────────────┐  │ │
│  │  │ Navigation Bar   │────▶│ Dark Theme       │ │ Auth Manager  │  │ │
│  │  │ Auth Forms       │     │ Glass Morphism   │ │ Token Storage │  │ │
│  │  │ Search Form      │     │ Gradients        │ │ API Calls     │  │ │
│  │  │ Results Grids    │     │ Animations       │ │ UI Updates    │  │ │
│  │  └──────────────────┘     └──────────────────┘ └──────────────┘  │ │
│  │                                                                    │ │
│  │  localStorage: JWT Token (persists across sessions)              │ │
│  │  const API = window.location.origin (auto-detects backend URL)   │ │
│  └────────────────────────────────────────────────────────────────────┘ │
│                                                                           │
│                                    ▼                                      │
│                        HTTP REST API Calls                               │
│                    (JSON + Authorization Header)                         │
│                                    ▼                                      │
└─────────────────────────────────────────────────────────────────────────┘
                                     │
                                     │
                    ┌────────────────▼──────────────────┐
                    │  Network / Internet / Localhost   │
                    └────────────────▲──────────────────┘
                                     │
┌─────────────────────────────────────────────────────────────────────────┐
│                     YOUR SERVER (Backend)                               │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                           │
│  ┌────────────────────────────────────────────────────────────────────┐ │
│  │              FastAPI Application (backend.py)                      │ │
│  │                                                                    │ │
│  │  Middleware:                                                       │ │
│  │  ┌──────────────────────────────────────────────────────────┐    │ │
│  │  │ CORS Middleware (allow requests from any origin)        │    │ │
│  │  │ Request logging & error handling                        │    │ │
│  │  └──────────────────────────────────────────────────────────┘    │ │
│  │                                                                    │ │
│  │  Routes:                                                          │ │
│  │  ┌──────────────┐  ┌──────────────────┐  ┌────────────────┐     │ │
│  │  │ GET  /       │  │ POST /api/login  │  │ POST /api/me   │     │ │
│  │  │ (Serve HTML) │  │ (Auth)           │  │ (Protected)    │     │ │
│  │  └──────────────┘  └──────────────────┘  └────────────────┘     │ │
│  │                                                                    │ │
│  │  ┌─────────────────┐  ┌──────────────────────────────────────┐   │ │
│  │  │ POST /register  │  │ POST /api/recommend (Protected)      │   │ │
│  │  │ (Auth)          │  │ (Core recommendation engine)         │   │ │
│  │  └─────────────────┘  └──────────────────────────────────────┘   │ │
│  │                                                                    │ │
│  │  Security:                                                        │ │
│  │  ┌──────────────────────────────────────────────────────────┐    │ │
│  │  │ JWT Token Validation (get_current_user dependency)      │    │ │
│  │  │ Password Hashing (bcrypt)                               │    │ │
│  │  │ HTTPBearer security scheme                              │    │ │
│  │  └──────────────────────────────────────────────────────────┘    │ │
│  └────────────────────────────────────────────────────────────────────┘ │
│                                                                           │
│  ┌────────────────────────────────────────────────────────────────────┐ │
│  │          Recommendation Engine (database.py)                       │ │
│  │                                                                    │ │
│  │  1. TF-IDF Vectorization (50% weight)                            │ │
│  │     - Converts text to vectors                                   │ │
│  │     - Measures semantic similarity                               │ │
│  │                                                                    │ │
│  │  2. Token Heuristic Matching (30% weight)                        │ │
│  │     - Counts matching keywords                                   │ │
│  │     - Fast computation                                           │ │
│  │                                                                    │ │
│  │  3. Level Matching (20% weight)                                  │ │
│  │     - Maps user role → seniority level                           │ │
│  │     - Matches course difficulty                                  │ │
│  │                                                                    │ │
│  │  Output: Items ranked 0-100% match                               │ │
│  └────────────────────────────────────────────────────────────────────┘ │
│                                                                           │
│  ┌────────────────────────────────────────────────────────────────────┐ │
│  │              SQLite3 Database (moocs.db)                           │ │
│  │                                                                    │ │
│  │  ┌─────────────┐  ┌───────────────┐  ┌─────────────────┐        │ │
│  │  │ Users Table │  │ Courses Table │  │ Internships Tbl │        │ │
│  │  ├─────────────┤  ├───────────────┤  ├─────────────────┤        │ │
│  │  │ id (PK)     │  │ id (PK)       │  │ id (PK)         │        │ │
│  │  │ email (UQ)  │  │ title         │  │ title           │        │ │
│  │  │ password_h  │  │ provider      │  │ company         │        │ │
│  │  │ name        │  │ level         │  │ location        │        │ │
│  │  │ created_at  │  │ duration      │  │ stipend         │        │ │
│  │  │             │  │ tags          │  │ tags            │        │ │
│  │  │             │  │ description   │  │ description     │        │ │
│  │  │             │  │ url           │  │ url             │        │ │
│  │  └─────────────┘  └───────────────┘  └─────────────────┘        │ │
│  │                                                                    │ │
│  │  500+ Courses | 1000+ Internships | Auto-seeded on startup       │ │
│  └────────────────────────────────────────────────────────────────────┘ │
│                                                                           │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## 🔄 Request-Response Flow Diagrams

### 1. User Registration Flow

```
Frontend                                Backend                 Database
   │                                      │                         │
   │──── POST /api/register ────────────────▶                        │
   │     {                                  │                        │
   │       name, email, password            │                        │
   │     }                                  │                        │
   │                                        │─── Validate input ──┐   │
   │                                        │                    │   │
   │                                        │◀─── Check unique ──┘   │
   │                                        │                        │
   │                                        │─── Hash password ──┐   │
   │                                        │                    │   │
   │                                        ├─ INSERT user ─────────▶│
   │                                        │                    │   │
   │                                        │◀─── OK ────────────────┤
   │                                        │                        │
   │                                        │─── Create JWT ─────┐   │
   │                                        │                    │   │
   │◀──── 200 + JWT Token ──────────────────┤                    │   │
   │     {                                  │                    │   │
   │       token: "eyJ0eXAi...",            │                    │   │
   │       name, email                      │                    │   │
   │     }                                  │                    │   │
   │                                        │                    │   │
   ├─ localStorage.setItem("token") ────┐   │                    │   │
   │                                    │   │                    │   │
   │ (Token now used in future requests)    │                    │   │
   │                                        │                    │   │
```

### 2. Getting Recommendations Flow

```
Frontend                       Backend              Database
   │                              │                    │
   │─ POST /api/recommend ───────▶│                    │
   │   {                          │                    │
   │     skills: "Python, ML",    │                    │
   │     role: "Data Scientist"   │─ Validate JWT ─┐  │
   │   }                          │                │  │
   │   Header:                    │◀─ Token OK ────┘  │
   │   Authorization: Bearer      │                   │
   │   <token>                    │─ Query courses ────▶│
   │                              │                    │
   │                              │◀─ 500 courses ────│
   │                              │                   │
   │                              ├─ Query internships ▶│
   │                              │                    │
   │                              │◀─ 1000 internships │
   │                              │                    │
   │                              │─ Rank items ──┐   │
   │                              │   (AI Engine) │   │
   │                              │               │   │
   │                              │  TF-IDF       │   │
   │                              │  + Token Mtch │   │
   │                              │  + Level Mtch │   │
   │                              │               │   │
   │◀─ 200 + Results ───────────┤               │   │
   │   {                         │               │   │
   │     courses: [              │               │   │
   │       {                     │               │   │
   │         title: "...",       │               │   │
   │         match: 92%,         │               │   │
   │         ...                 │               │   │
   │       }                     │               │   │
   │     ],                      │               │   │
   │     internships: [...]      │               │   │
   │   }                         │               │   │
   │                             │               │   │
   ├─ Render cards in HTML ─┐   │               │   │
   │                        │   │               │   │
   │ Display match % & data │   │               │   │
   │                        │   │               │   │
```

### 3. Token Validation (Protected Endpoint)

```
Frontend                    Backend
   │                           │
   │─ GET /api/me ────────────▶│
   │   Header:                 │
   │   Authorization:          │─ Extract token ──┐
   │   Bearer <token>          │                  │
   │                           │─ Verify JWT ────┐│
   │                           │                 ││
   │                           ├─ Check expiry  │
   │                           │                 │
   │                           ├─ Decode payload│
   │                           │                 │
   │                           │ Valid? ─┐      │
   │                           │         │      │
   │◀──── 200 + user data ────│         │      │
   │      {                    │         │      │
   │        name: "John",      │         │      │
   │        email: "..."       │         │      │
   │      }                    │         │      │
   │                           │         │      │
   │                           │ Invalid? ──┐   │
   │◀──── 401 Unauthorized ───│            │   │
   │                           │            │   │
```

---

## 🔌 Connection Points

### Point 1: Frontend Detects Backend URL

```javascript
// index.html - Line ~345
const API = window.location.origin;

// Examples:
// localhost:8080    → http://localhost:8080
// example.com       → https://example.com
// 192.168.1.100:80  → http://192.168.1.100:80

// This means frontend automatically connects to whatever server served it!
```

### Point 2: Frontend Persists Authentication

```javascript
// index.html - Line ~370
function setToken(t) {
  token = t;
  localStorage.setItem("learnpath_token", t);  // ← Persists across refreshes
  updateNavUI();
}

// When user closes and reopens browser:
function getToken() {
  return localStorage.getItem("learnpath_token");  // ← Token still there!
}
```

### Point 3: Backend Validates Every Protected Request

```python
# backend.py - Line ~48
def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    if not credentials:
        raise HTTPException(status_code=401, detail="Not authenticated")
    try:
        return jwt.decode(credentials.credentials, SECRET_KEY, algorithms=[ALGORITHM])
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid or expired token")

# Usage:
@app.post("/api/recommend")
def recommend(req: RecommendRequest, current_user: dict = Depends(get_current_user)):
    # ↑ This dependency ensures only logged-in users can access
    ...
```

### Point 4: Backend Serves Frontend at Root

```python
# backend.py - Line ~75
@app.get("/", response_class=HTMLResponse)
def serve_frontend():
    html_path = os.path.join(BASE_DIR, "index.html")
    with open(html_path, "r", encoding="utf-8") as f:
        return HTMLResponse(content=f.read())

# When browser accesses http://localhost:8080/
# This endpoint returns the complete index.html file
# Browser then runs all the JavaScript in that file
```

### Point 5: Database Auto-Seeds on Startup

```python
# database.py - Line ~56
@app.on_event("startup")
def startup():
    init_db()  # Called once when server starts
    print("[✓] Database initialized successfully")

# First run: Creates tables + adds 500 courses, 1000 internships
# Subsequent runs: Uses existing data
```

---

## 📊 Data Transformation Pipeline

### From User Input to Match Percentage

```
User Input:
"Skills: Python, Machine Learning, TensorFlow"
"Role: Data Scientist"
            │
            ▼
┌─────────────────────────────────────────┐
│ Tokenization (database.py - stream_tokenize)
│ • Remove stop words (and, or, the, ...)
│ • Extract keywords: [python, machine, learning, tensorflow, data, scientist]
│ • Normalize to lowercase
└─────────────────────────────────────────┘
            │
            ▼
┌─────────────────────────────────────────┐
│ TF-IDF Vectorization (50% weight)
│ • Convert to vector representation
│ • Compute cosine similarity with each course
│ • Example: 0.78 similarity → decent match
└─────────────────────────────────────────┘
            │
            ▼
┌─────────────────────────────────────────┐
│ Token Heuristic (30% weight)
│ • Count intersecting tokens
│ • "Python" in course tags? ✓
│ • "Machine Learning" in description? ✓
│ • Score: 3 matches / 6 user tokens = 0.5
└─────────────────────────────────────────┘
            │
            ▼
┌─────────────────────────────────────────┐
│ Level Matching (20% weight)
│ • Map "Data Scientist" → Intermediate/Advanced
│ • Course level = Intermediate → Perfect match! 1.0
└─────────────────────────────────────────┘
            │
            ▼
┌─────────────────────────────────────────┐
│ Final Score Calculation
│ score = (0.78 × 0.5) + (0.5 × 0.3) + (1.0 × 0.2)
│       = 0.39 + 0.15 + 0.20
│       = 0.74
│ → 74% Match! ✓
└─────────────────────────────────────────┘
            │
            ▼
     Display to User
```

---

## 🔒 Security Architecture

### Authentication Flow

```
User → Frontend (HTML/JS) → Backend (FastAPI)
                 ↓
         1. POST /register
         2. Backend hashes password with bcrypt
         3. Stores in database
         4. Returns JWT token
         5. Frontend stores in localStorage
         6. Future requests include token
         7. Backend validates token with get_current_user()
         8. If valid → Allow access
            If invalid → 401 Unauthorized
```

### Token Structure (JWT)

```javascript
{
  "header": {
    "alg": "HS256",
    "typ": "JWT"
  },
  "payload": {
    "sub": "123",              // User ID
    "email": "user@email.com",
    "name": "John Doe",
    "exp": 1704067200         // Expires in 24 hours
  },
  "signature": "..." // Signed with SECRET_KEY
}

// Token sent as:
// Authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJz...
```

### Password Security

```python
# Registration
plaintext = "MyPassword123"
hashed = bcrypt.hash(plaintext)
# Stored in database: $2b$12$...

# Login
def verify_password(plaintext, hashed):
    return bcrypt.verify(plaintext, hashed)
    # Securely compares without revealing password
```

---

## 🧪 Testing the Connections

### Test 1: Frontend Loads

```bash
# Open browser
curl http://localhost:8080

# Should return: <!DOCTYPE html>...
```

### Test 2: Registration Works

```bash
curl -X POST http://localhost:8080/api/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Test User",
    "email": "test@example.com",
    "password": "password123"
  }'

# Should return:
# {
#   "status": "success",
#   "token": "eyJ0eXAi...",
#   "name": "Test User",
#   "email": "test@example.com"
# }
```

### Test 3: Login Works

```bash
curl -X POST http://localhost:8080/api/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "password123"
  }'

# Should return token
```

### Test 4: Protected Endpoint

```bash
# Without token
curl http://localhost:8080/api/me
# Returns: 401 Unauthorized

# With token
TOKEN="eyJ0eXAi..."
curl http://localhost:8080/api/me \
  -H "Authorization: Bearer $TOKEN"
# Returns: {"name": "Test User", "email": "..."}
```

### Test 5: Recommendations

```bash
TOKEN="eyJ0eXAi..."
curl -X POST http://localhost:8080/api/recommend \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "skills": "Python Machine Learning",
    "role": "Data Scientist"
  }'

# Should return:
# {
#   "status": "success",
#   "courses": [
#     {"title": "...", "match": 85, ...},
#     ...
#   ],
#   "internships": [...]
# }
```

---

## 📈 Performance Optimization

### Frontend Optimization
- Lazy loading of card grids
- Token cached in localStorage
- Async API calls (no blocking)
- CSS animations use GPU (transform, opacity)

### Backend Optimization
- Connection pooling for SQLite
- Caching of TF-IDF vectorizer state
- Pagination-ready (can add limit/offset)
- JWT validation in dependency injection

### Database Optimization
- Indexed columns (id, email)
- Separate tables for courses/internships
- Full-text search capable (with extensions)

---

## 🚀 Scaling Considerations

### Current Limitations
- SQLite (single user writes)
- In-memory recommendation engine
- No caching layer

### For Production
1. **Database**: Migrate to PostgreSQL
2. **Cache**: Add Redis for token blacklist
3. **Search**: Use Elasticsearch for full-text search
4. **API Gateway**: Add rate limiting
5. **Queue**: Use Celery for async resume parsing
6. **Monitor**: Add Prometheus/Grafana

---

Made with ❤️ by LearnPath AI

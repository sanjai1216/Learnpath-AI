# 🚀 LearnPath AI - Complete Connected Setup

## ✅ What You Now Have

Your LearnPath AI is **fully connected** and ready to run! Here's everything included:

### 📦 Core Files
- **backend.py** - FastAPI server with all API endpoints
- **index.html** - Beautiful frontend UI (auto-detects backend)
- **database.py** - SQLite database + AI recommendation engine
- **requirements.txt** - All Python dependencies

### 📚 Documentation
- **INTEGRATION_GUIDE.md** - How everything connects together
- **ARCHITECTURE.md** - Deep dive into system design & security
- **HOSTING_GUIDE.md** - Detailed hosting platform comparison & deployment

### 🛠️ Startup Scripts
- **run.sh** - Linux/Mac quick start script
- **run.bat** - Windows quick start script

---

## ⚡ Quick Start (2 minutes)

### Option 1: Using Script (Easiest)

**On Mac/Linux:**
```bash
chmod +x run.sh
./run.sh
```

**On Windows:**
```bash
run.bat
```

### Option 2: Manual Start

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Run the server
python backend.py

# 3. Open browser
http://localhost:8080
```

You should see:
```
[✓] Database initialized successfully
[✓] Starting LearnPath AI on http://0.0.0.0:8080
[✓] Open browser at http://localhost:8080
```

---

## 🎯 How It All Works

### Frontend ← → Backend ← → Database

```javascript
// index.html detects backend automatically
const API = window.location.origin;

// When you access http://localhost:8080:
// ✓ Frontend loads from backend
// ✓ Frontend calls API endpoints
// ✓ Backend queries database
// ✓ Results returned to frontend
// ✓ Beautiful UI displays recommendations
```

### Connection Flow

```
1. User visits http://localhost:8080
   ↓
2. Backend serves index.html
   ↓
3. Frontend initializes with automatic API detection
   ↓
4. User registers/logs in
   ↓
5. JWT token created & stored locally
   ↓
6. User enters skills & role
   ↓
7. Frontend calls /api/recommend
   ↓
8. Backend queries database (500 courses + 1000 internships)
   ↓
9. AI engine ranks by relevance (0-100% match)
   ↓
10. Results displayed with beautiful cards
```

---

## 🧪 Test It Out

### 1. Create Account
```
Email: test@example.com
Password: password123
Name: Your Name
```

### 2. Search for Recommendations
```
Skills: Python, Machine Learning, Data Science
Role: Data Scientist
```

### 3. See Results
```
✓ Top 10 courses ranked by match
✓ Top 10 internships ranked by match
✓ Match percentage for each (0-100%)
✓ Click "Enroll" or "Apply" to view details
```

### 4. Upload Resume (Optional)
```
Upload a text file with your resume
System extracts skills automatically
Suggests role based on content
```

---

## 🔐 Security Features Built-In

✅ **Password Hashing** - bcrypt encryption
✅ **JWT Tokens** - Secure authentication
✅ **Protected Endpoints** - Only logged-in users can access
✅ **Token Expiry** - 24 hours validity
✅ **Email Validation** - Prevents duplicates

---

## 🎨 Features Included

### Authentication
- ✅ User registration with validation
- ✅ Secure login system
- ✅ JWT token-based auth
- ✅ Session persistence

### Recommendations
- ✅ AI-powered matching (TF-IDF + Vector similarity)
- ✅ 500+ courses in database
- ✅ 1000+ internships in database
- ✅ Match percentage scoring (0-100%)

### UI/UX
- ✅ Dark theme with glassmorphism
- ✅ Smooth animations
- ✅ Responsive design (mobile-friendly)
- ✅ Tab-based filtering (Courses/Internships)
- ✅ Beautiful gradient accents

---

## 📁 File Structure

```
learnpath-ai/
├── backend.py              # FastAPI server
├── index.html              # Frontend (HTML + CSS + JS)
├── database.py             # Database + recommendation engine
├── requirements.txt        # Dependencies
├── moocs.db               # SQLite database (auto-created)
├── run.sh                 # Linux/Mac startup script
├── run.bat                # Windows startup script
├── INTEGRATION_GUIDE.md   # Setup & troubleshooting
├── ARCHITECTURE.md        # Technical deep dive
└── HOSTING_GUIDE.md       # Deployment guide
```

---

## 🌐 Deployment Options

### Quick & Free
1. **Render** - 5 min setup, free tier available
2. **Railway** - 3 min setup, $5/month credits
3. **PythonAnywhere** - 10 min setup, $5/month

### Best Value
**DigitalOcean** - $5/month VPS (full control)

### Enterprise
**AWS / GCP / Azure** - Infinite scaling

**→ See HOSTING_GUIDE.md for detailed comparison**

---

## ❓ FAQ

### Q: My frontend can't connect to backend?
**A:** Make sure backend is running on port 8080
```bash
python backend.py
# Check console for: "Starting LearnPath AI on http://0.0.0.0:8080"
```

### Q: "Cannot connect to server" error?
**A:** Backend might not be running. Run: `python backend.py`

### Q: How do I deploy to production?
**A:** See HOSTING_GUIDE.md - step-by-step for Render, Railway, DigitalOcean, etc.

### Q: Can I change the database?
**A:** Yes! Replace SQLite with PostgreSQL in database.py (see ARCHITECTURE.md)

### Q: How do I add more courses?
**A:** Edit `_seed_courses()` in database.py and delete moocs.db to reset

### Q: Can I customize the UI?
**A:** Yes! Edit CSS variables in index.html's <style> section

---

## 🔧 Customization Ideas

### Change Colors
```css
:root {
  --primary: #6c63ff;    /* Purple */
  --pink: #f059da;       /* Pink */
  --cyan: #00d4ff;       /* Cyan */
  --green: #00e5a0;      /* Green */
  /* Change these to your brand colors */
}
```

### Add More Internships
```python
# In database.py, add to _seed_internships() function:
("Your Internship", "Company Name", "Location", "$Stipend",
 "Python Django Web", "Description here",
 "https://example.com")
```

### Modify Recommendation Weights
```python
# In database.py, line ~570
score = (c * 0.5) + (h * 0.3) + (l * 0.2)
# Adjust: 0.5 (TF-IDF), 0.3 (heuristic), 0.2 (level)
```

---

## 📊 Key Technologies

| Component | Technology | Purpose |
|-----------|-----------|---------|
| Backend | FastAPI (Python) | REST API + Auth |
| Frontend | HTML5 + CSS3 + JS | User Interface |
| Database | SQLite3 | Data Storage |
| Security | JWT + bcrypt | Authentication |
| ML | scikit-learn | Recommendation Engine |

---

## 🚀 Next Steps

### Immediate
1. Run the app: `python backend.py`
2. Test in browser: `http://localhost:8080`
3. Register & search for recommendations

### Soon
1. Customize colors/branding
2. Add your own courses/internships
3. Deploy to free hosting (Render/Railway)

### Later
1. Migrate to PostgreSQL
2. Add resume parsing
3. Implement user profiles
4. Add saved recommendations feature

---

## 📚 Documentation

Each guide covers specific aspects:

- **INTEGRATION_GUIDE.md** - Start here! Full setup & troubleshooting
- **ARCHITECTURE.md** - Technical details, security, performance
- **HOSTING_GUIDE.md** - Deployment options & step-by-step guides

---

## 💬 Need Help?

**For Setup Issues:**
→ Check INTEGRATION_GUIDE.md (Troubleshooting section)

**For Technical Questions:**
→ Check ARCHITECTURE.md (detailed explanations)

**For Deployment:**
→ Check HOSTING_GUIDE.md (step-by-step for each platform)

---

## ✨ You're All Set!

Your full-stack app is **ready to run** with:
- ✅ Frontend connected to backend
- ✅ Backend connected to database
- ✅ Database auto-seeded with 500+ courses & 1000+ internships
- ✅ AI recommendation engine working
- ✅ Secure authentication system
- ✅ Beautiful, responsive UI

### Start now:
```bash
python backend.py
# Then open: http://localhost:8080
```

Good luck! 🎉

---

**Made with ❤️ by LearnPath AI**

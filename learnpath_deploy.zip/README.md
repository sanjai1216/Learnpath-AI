# LearnPath AI — Deployment Guide

## 🚀 Deploy to Render.com (Free, Permanent URL)

### Step 1 — Create GitHub Account
Go to https://github.com and sign up (free).

### Step 2 — Create a New Repository
1. Click the **+** button → **New repository**
2. Name it: `learnpath-ai`
3. Set to **Public**
4. Click **Create repository**

### Step 3 — Upload these 4 files to GitHub
Drag and drop all 4 files into your repo:
- `backend.py`
- `database.py`
- `requirements.txt`
- `render.yaml`

Click **Commit changes**.

### Step 4 — Deploy on Render
1. Go to https://render.com and sign up with GitHub
2. Click **New** → **Web Service**
3. Connect your `learnpath-ai` GitHub repo
4. Render auto-detects settings from `render.yaml`
5. Click **Create Web Service**
6. Wait ~3 minutes for deploy ✅

### Step 5 — Open your live website!
Render gives you a permanent URL like:
```
https://learnpath-ai.onrender.com
```
Share it with anyone — works on any device, anywhere!

---

## 💻 Run Locally
```bash
pip install -r requirements.txt
python backend.py
# Open http://127.0.0.1:8000
```

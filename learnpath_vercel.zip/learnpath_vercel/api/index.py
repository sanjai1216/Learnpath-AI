import sys
import os

# Add the project root to Python path so backend.py and database.py are importable
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from backend import app  # noqa: F401 — Vercel looks for `app`
